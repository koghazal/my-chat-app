const http = require('http'), fs = require('fs'), path = require('path');
const { WebSocketServer } = require('ws');
const D = require('./db'), N = require('./net');
const PORT = process.env.PORT || 3000;
const PAGE = path.join(__dirname, 'public', 'index.html');
const LOBBY = 'الصالة العامة';

const server = http.createServer((req, res) => {
  if (req.url !== '/') { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  fs.createReadStream(PAGE).pipe(res);
});
const wss = new WebSocketServer({ server, maxPayload: 4096 });

D.db.exec('DELETE FROM rooms WHERE permanent = 0');
const rooms = new Map(D.db.prepare('SELECT name, permanent FROM rooms').all().map(r => [r.name, !!r.permanent]));
const users = new Map(), socks = new Set();
const BAD = []; // ضيف هنا الكلمات الممنوعة
let nextId = 1;

const hex = v => /^#[0-9a-f]{6}$/i.test(v) ? v : '';
const parseStyle = j => { try { return JSON.parse(j || '{}'); } catch { return {}; } };
const clean = s => String(s ?? '').replace(/[\u0000-\u001f\u200e\u200f\u202a-\u202e]/g, '').trim();
const filter = t => BAD.reduce((x, w) => x.split(w).join('***'), t);
const send = (u, o) => u.ws.readyState === 1 && u.ws.send(JSON.stringify(o));
const notice = (u, title, text) => send(u, { t: 'notice', title, text });
const ACTAR = { kick: 'طرد', kickroom: 'طرد من الغرفة', mute: 'اسكات', ban: 'باند', tempban: 'باند مؤقت', setrole: 'تغيير الرتبة', move: 'نقل لغرفة', likes: 'تعديل الإيكات' };
const inRoom = r => [...users.values()].filter(u => u.room === r);
const toRoom = (r, o) => inRoom(r).forEach(u => send(u, o));
const toSocks = o => { const s = JSON.stringify(o); socks.forEach(x => x.readyState === 1 && x.send(s)); };
const site = () => ({ t: 'site', name: D.setting('site_name'), welcome: D.setting('welcome'), rules: D.setting('rules') });
const pushRooms = () => toSocks({ t: 'rooms', list: [...rooms.keys()].map(n => ({ name: n, count: inRoom(n).length })) });
const pushUsers = r => toRoom(r, { t: 'users', list: inRoom(r).map(u => ({ id: u.id, name: u.name, role: u.role, label: D.label(u.role), status: u.status, style: u.style })) });
const pushOnline = () => toSocks({ t: 'online', count: users.size, list: [...users.values()].slice(-30).reverse().map(u => ({ id: u.id, name: u.name, room: u.room })) });
const tooFast = u => { const n = Date.now(); u.stamps = u.stamps.filter(t => n - t < 3000); u.stamps.push(n); return u.stamps.length > 5; };

function leave(u) {
  const old = u.room; if (!old) return;
  u.room = null;
  toRoom(old, { t: 'sys', text: `${u.name} غادر الغرفة` });
  if (!rooms.get(old) && !inRoom(old).length) { rooms.delete(old); D.delRoom(old); }
  pushUsers(old);
}
function join(u, r) {
  if (!rooms.has(r) || u.room === r) return;
  leave(u); u.room = r;
  send(u, { t: 'joined', room: r });
  send(u, { t: 'history', list: D.history(r) });
  toRoom(r, { t: 'sys', text: `${u.name} دخل الغرفة` });
  pushRooms(); pushUsers(r); pushOnline();
}

const PERMOF = { kick: 'kick', kickroom: 'kickroom', mute: 'mute', ban: 'ban', tempban: 'tempban', setrole: 'setrole', move: 'moverooms', likes: 'editlikes' };
const rolesInfo = u => ({ catalog: D.PERMS, list: D.rolesList().filter(r => r.name !== 'owner' && r.level < D.level(u.role)) });
function whois(u, v) {
  const st = v.uid ? D.stats(v.uid) : { points: 0, likes: 0 };
  send(u, { t: 'whois', id: v.id, name: v.name, role: v.role, label: D.label(v.role), room: v.room, status: v.status, style: v.style, points: st.points, likes: st.likes, member: !!v.uid });
}

function admin(u, m) {
  const op = m.op;
  if (op === 'setting') {
    const k = String(m.key);
    if (!D.can(u.role, 'settings') || !D.SETTING_KEYS.includes(k)) return;
    D.setSetting(k, clean(m.value).slice(0, 500)); D.audit(u.name, 'setting', null, k);
    return toSocks(site());
  }
  if (op === 'setperms') {
    const r = String(m.role);
    if (!D.can(u.role, 'roles') || !D.roleExists(r) || r === 'owner' || D.level(r) >= D.level(u.role)) return;
    D.setPerms(r, Array.isArray(m.perms) ? m.perms.map(String) : []); D.audit(u.name, 'setperms', r, D.perms(r).join('، '));
    users.forEach(x => x.role === r && send(x, { t: 'perms', role: r, perms: D.perms(r) }));
    return send(u, { t: 'roles', ...rolesInfo(u) });
  }
  const v = users.get(Number(m.target));
  if (!v || v === u || !PERMOF[op] || !D.can(u.role, PERMOF[op])) return;
  if (D.level(v.role) >= D.level(u.role)) return send(u, { t: 'err', text: 'مفيش صلاحية على العضو ده' });
  const mins = Math.min(Math.max(Math.floor(Number(m.mins)) || 0, 0), 525600);
  const det = { mute: mins ? mins + 'د' : 'فك', tempban: mins + 'د', ban: 'دائم', move: clean(m.room), likes: String(m.value), setrole: String(m.role) }[op] || '';
  const who = `"${v.name}"`;
  let said = '';
  if (op === 'kick') { notice(v, 'تم طردك', `قام ${u.name} بطردك من الدردشة.`); v.ws.close(); said = `تم طرد ${who} من الدردشة وفصله عن الموقع.`; }
  if (op === 'kickroom') {
    if (v.room === LOBBY) return notice(u, 'ملحوظة', `${who} موجود في الصالة العامة أصلًا.`);
    notice(v, 'تم طردك من الغرفة', `قام ${u.name} بنقلك إلى الصالة العامة.`); join(v, LOBBY);
    said = `تم طرد ${who} من الغرفة ونقله إلى الصالة العامة.`;
  }
  if (op === 'mute') {
    v.mutedUntil = mins ? Date.now() + mins * 60e3 : 0; if (v.uid) D.setCol(v.uid, 'muted_until', v.mutedUntil);
    notice(v, mins ? 'تم إسكاتك' : 'تم فك الإسكات', mins ? `قام ${u.name} بإسكاتك ${mins} دقيقة، ومش هتقدر تكتب رسايل لحد ما المدة تخلص.` : `قام ${u.name} بفك الإسكات عنك، تقدر تكتب تاني.`);
    said = mins ? `تم إسكات ${who} لمدة ${mins} دقيقة. مش هيقدر يكتب رسايل خلال المدة دي.` : `تم فك الإسكات عن ${who} وبقى يقدر يكتب.`;
  }
  if (op === 'ban' || op === 'tempban') {
    const until = Date.now() + (op === 'ban' ? 3650 * 864e5 : Math.max(mins, 1) * 60e3);
    const how = op === 'ban' ? 'بشكل دائم' : `لمدة ${Math.max(mins, 1)} دقيقة`;
    if (v.uid) D.setCol(v.uid, 'banned_until', until);
    D.addBlock('device', v.info.did, u.name, until); if (!v.uid) D.addBlock('ip', v.info.ip, u.name, until);
    notice(v, 'تم حظرك', `قام ${u.name} بحظرك ${how}.`); v.ws.close();
    said = `تم حظر ${who} ${how} (${v.uid ? 'الحساب والجهاز' : 'الجهاز والايبي'}). تقدر تفك الحظر من لوحة التحكم ← المحظورين.`;
  }
  if (op === 'move') {
    const r = clean(m.room); if (!rooms.has(r)) return;
    notice(v, 'تم نقلك', `قام ${u.name} بنقلك إلى غرفة "${r}".`); join(v, r); said = `تم نقل ${who} إلى غرفة "${r}".`;
  }
  if (op === 'likes') {
    const n = Math.floor(Number(m.value));
    if (!v.uid || !(n >= 0 && n <= 1e9)) return send(u, { t: 'err', text: 'قيمة غير صالحة' });
    D.setCol(v.uid, 'likes', n); said = `تم تعديل إيكات ${who} إلى ${n}.`;
  }
  if (op === 'setrole') {
    const r = String(m.role);
    if (!v.uid || !D.roleExists(r) || D.level(r) >= D.level(u.role)) return send(u, { t: 'err', text: 'رتبة غير صالحة' });
    D.setCol(v.uid, 'role', r); v.role = r;
    send(v, { t: 'perms', role: r, perms: D.perms(r) }); pushUsers(v.room);
    notice(v, 'تغيرت رتبتك', `قام ${u.name} بتغيير رتبتك إلى ${D.label(r)}.`); said = `تم تغيير رتبة ${who} إلى ${D.label(r)}.`;
  }
  D.audit(u.name, op, v.name, det);
  notice(u, 'تم تنفيذ: ' + ACTAR[op], said + '\nتم تسجيل الإجراء في الحالات.');
}

wss.on('connection', (ws, req) => {
  let u = null, fails = 0;
  const ip = N.clientIp(req), dq = new URL(req.url, 'http://x').searchParams.get('d') || '';
  const info = { ip, country: N.clientCountry(req, ip), ...N.parseUA(req.headers['user-agent']), did: /^[\w-]{8,64}$/.test(dq) ? dq : '' };
  socks.add(ws); ws.send(JSON.stringify(site())); pushOnline();
  const err = x => { ws.send(JSON.stringify({ t: 'err', text: x })); if (++fails >= 8) ws.close(); };
  const online = n => [...users.values()].some(x => x.name.toLowerCase() === n.toLowerCase());
  const enter = (row, name, token) => {
    if (row?.role !== 'owner' && D.blockedBy(info.ip, info.did)) { ws.send(JSON.stringify({ t: 'err', text: 'تم حظر الدخول من جهازك أو شبكتك' })); return ws.close(); }
    if (row) { const dup = [...users.values()].find(x => x.uid === row.id); if (dup) { send(dup, { t: 'err', text: 'دخلت من جهاز تاني' }); dup.ws.close(); } }
    u = { id: nextId++, uid: row?.id ?? null, name, role: row?.role ?? 'guest', style: parseStyle(row?.style), status: row?.status_msg || '', ws, room: null, stamps: [], reports: new Set(), mutedUntil: row?.muted_until || 0 };
    users.set(u.id, u); u.info = info; u.since = Date.now(); u.visit = D.visit(u, info);
    send(u, { t: 'welcome', id: u.id, name, role: u.role, perms: D.perms(u.role), token });
    join(u, LOBBY);
  };

  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (!m || typeof m !== 'object') return;

    if (!u) {
      if (m.t === 'resume') {
        const row = D.sessionUser(String(m.token));
        if (!row) return ws.send(JSON.stringify({ t: 'badtoken' }));
        if (row.banned_until > Date.now()) return err('الحساب محظور مؤقتًا');
        D.touch(row.id); return enter(row, row.username, String(m.token));
      }
      const name = clean(m.name).slice(0, 20);
      if (m.t === 'login' && m.pass !== undefined) {
        const row = D.login(name, String(m.pass));
        if (!row) return err('الاسم أو كلمة المرور غلط');
        if (row.banned_until > Date.now()) return err('الحساب محظور مؤقتًا');
        D.touch(row.id); return enter(row, row.username, D.newSession(row.id));
      }
      if (m.t === 'login') {
        if (name.length < 2) return err('الاسم لازم يكون حرفين على الأقل');
        if (D.userExists(name)) return err('الاسم ده لعضو مسجّل، سجّل دخول بكلمة المرور');
        if (online(name)) return err('الاسم مستخدم، اختار اسم تاني');
        return enter(null, name);
      }
      if (m.t === 'register') {
        const pass = String(m.pass ?? '');
        if (!/^[\p{L}\p{N}_ ]{3,20}$/u.test(name)) return err('الاسم 3 إلى 20 حرف (حروف وأرقام فقط)');
        if (pass.length < 6 || pass.length > 72) return err('كلمة المرور 6 أحرف على الأقل');
        if (D.userExists(name) || online(name)) return err('الاسم مستخدم، اختار اسم تاني');
        const row = D.createUser(name, pass);
        return enter(row, row.username, D.newSession(row.id));
      }
      return;
    }

    if (m.t === 'join') return join(u, clean(m.room));
    if (m.t === 'mkroom') {
      const r = clean(m.name).slice(0, 24);
      if (r.length < 2 || rooms.has(r) || rooms.size >= 30) return send(u, { t: 'err', text: 'تعذّر إنشاء الغرفة: الاسم قصير أو موجود، أو وصلنا للحد الأقصى' });
      rooms.set(r, false); D.addRoom(r, u.uid); return join(u, r);
    }
    if (m.t === 'msg' || m.t === 'pm') {
      const text = filter(clean(m.text).slice(0, 300)); if (!text) return;
      if (Date.now() < u.mutedUntil) return send(u, { t: 'err', text: 'أنت مكتوم مؤقتًا' });
      if (tooFast(u)) return send(u, { t: 'err', text: 'بالراحة شوية، الرسايل بتتبعت بسرعة' });
      if (m.t === 'msg') {
        if (!u.room) return;
        toRoom(u.room, { t: 'msg', id: u.id, name: u.name, text, style: u.style });
        D.logMsg(u.room, u.uid, u.name, text); if (u.uid) D.addPoint(u.uid); return;
      }
      const to = users.get(Number(m.to)); if (!to || to === u) return;
      const o = { t: 'pm', from: u.id, fromName: u.name, to: to.id, toName: to.name, text };
      send(u, o); return send(to, o);
    }
    if (m.t === 'profile' && u.uid) {
      u.style = { n: hex(m.n), t: hex(m.tx), b: hex(m.b), s: hex(m.s) };
      u.status = clean(m.status).slice(0, 60);
      D.setCol(u.uid, 'style', JSON.stringify(u.style)); D.setCol(u.uid, 'status_msg', u.status);
      return pushUsers(u.room);
    }
    if (m.t === 'passwd' && u.uid) {
      const np = String(m.np ?? '');
      if (!D.login(u.name, String(m.old ?? ''))) return send(u, { t: 'err', text: 'كلمة المرور الحالية غلط' });
      if (np.length < 6 || np.length > 72) return send(u, { t: 'err', text: 'كلمة المرور الجديدة 6 أحرف على الأقل' });
      D.setPass(u.uid, np);
      send(u, { t: 'token', token: D.newSession(u.uid) });
      return notice(u, 'تم تغيير كلمة المرور', 'كلمة مرورك اتغيرت، وجلسات الأجهزة التانية اتقفلت.');
    }
    if (m.t === 'reveal') {
      const v = users.get(Number(m.id)); if (!v || v === u || !D.can(u.role, 'reveal')) return;
      if (D.level(v.role) >= D.level(u.role)) return send(u, { t: 'err', text: 'مفيش صلاحية على العضو ده' });
      D.audit(u.name, 'reveal', v.name);
      const i = v.info;
      return send(u, { t: 'reveal', id: v.id, name: v.name, ip: i.ip, country: i.country, countryName: N.countryName(i.country), device: i.device, browser: i.browser, since: v.since, same: D.sameDevice(i.did, v.name) });
    }
    if (m.t === 'logs') {
      const need = { visits: 'viewlog', cases: 'viewcases', blocks: 'ban' }[m.kind];
      if (!need || !D.can(u.role, need)) return;
      let rows = m.kind === 'visits' ? D.visits() : m.kind === 'cases' ? D.cases() : D.blocks();
      if (m.kind === 'visits') rows = rows.map(r => { const h = D.level(r.role) >= D.level(u.role) && r.name !== u.name; return { ...r, ip: h ? 'مخفي' : r.ip, device: h ? '' : r.device, browser: h ? '' : r.browser, countryName: N.countryName(r.country) }; });
      return send(u, { t: 'logs', kind: m.kind, rows });
    }
    if (m.t === 'unblock' && D.can(u.role, 'ban')) {
      D.delBlock(Number(m.id)); D.audit(u.name, 'unblock', null, String(m.id));
      return send(u, { t: 'logs', kind: 'blocks', rows: D.blocks() });
    }
    if (m.t === 'whois') {
      const v = m.id != null ? users.get(Number(m.id)) : [...users.values()].find(x => x.name === clean(m.name));
      if (v) return whois(u, v);
      const r = D.userByName(clean(m.name));
      if (!r) return notice(u, 'غير متصل', 'العضو ده زائر وخرج من الدردشة، فمفيش بروفايل ليه.');
      return send(u, { t: 'whois', id: null, name: r.username, role: r.role, label: D.label(r.role), room: null, status: r.status_msg, style: parseStyle(r.style), points: r.points, likes: r.likes, member: true, offline: true });
    }
    if (m.t === 'like') {
      const v = users.get(Number(m.id)); if (!v || !v.uid || !u.uid || v === u) return;
      D.like(u.uid, v.uid); return whois(u, v);
    }
    if (m.t === 'alert') {
      const v = users.get(Number(m.id)); if (!v || v === u || tooFast(u)) return;
      send(v, { t: 'alert', fromName: u.name }); return notice(u, 'تم إرسال التنبيه', `وصل تنبيه إلى "${v.name}".`);
    }
    if (m.t === 'rolesinfo') return D.can(u.role, 'roles') && send(u, { t: 'roles', ...rolesInfo(u) });
    if (m.t === 'admin') return admin(u, m);
    if (m.t === 'report') {
      const v = users.get(Number(m.id)); if (!v || v === u) return;
      D.report(u.name, v.name); v.reports.add(u.id);
      if (v.reports.size >= 3) { v.mutedUntil = Date.now() + 300e3; v.reports.clear(); notice(v, 'تم إسكاتك مؤقتًا', 'وصلت عليك 3 بلاغات من أعضاء مختلفين، فتم إسكاتك 5 دقايق تلقائيًا.'); }
      notice(u, 'تم إرسال البلاغ', `تم تسجيل بلاغك على "${v.name}". لو وصلت 3 بلاغات من أعضاء مختلفين بيتم إسكاته 5 دقايق تلقائيًا.`);
    }
  });
  ws.on('close', () => {
    socks.delete(ws);
    if (!u) return;
    D.leaveVisit(u.visit); leave(u); users.delete(u.id); pushRooms(); pushOnline();
  });
});

setInterval(D.prune, 36e5);
server.listen(PORT, () => console.log(`http://localhost:${PORT}`));
