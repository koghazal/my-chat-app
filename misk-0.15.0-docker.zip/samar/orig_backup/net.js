// أدوات الشبكة: الايبي، الدولة، الجهاز، المتصفح
let geo = null; try { geo = require('geoip-lite'); } catch {}
const dn = (() => { try { return new Intl.DisplayNames(['ar'], { type: 'region' }); } catch { return null; } })();

exports.countryName = c => { try { return c && dn ? dn.of(c) : c || ''; } catch { return c || ''; } };

exports.clientIp = req => {
  const h = req.headers;
  const ip = h['cf-connecting-ip'] || (h['x-forwarded-for'] ? String(h['x-forwarded-for']).split(',').pop().trim() : req.socket.remoteAddress) || '';
  return String(ip).replace(/^::ffff:/, '').slice(0, 64);
};

exports.clientCountry = (req, ip) => {
  const c = String(req.headers['cf-ipcountry'] || '').toUpperCase();
  if (/^[A-Z]{2}$/.test(c) && c !== 'XX') return c;
  try { return geo?.lookup(ip)?.country || ''; } catch { return ''; }
};

exports.parseUA = (ua = '') => {
  const os = /Android/i.test(ua) ? 'Android' : /iPhone|iPad|iPod/i.test(ua) ? 'iOS' : /Windows/i.test(ua) ? 'Windows' : /Mac OS X|Macintosh/i.test(ua) ? 'macOS' : /Linux/i.test(ua) ? 'Linux' : 'غير معروف';
  const type = /iPad|Tablet/i.test(ua) || (/Android/i.test(ua) && !/Mobile/i.test(ua)) ? 'تابلت' : /Mobi|iPhone|Android/i.test(ua) ? 'موبايل' : 'كمبيوتر';
  const model = /Android[\s\d.]*;\s*([^;)]+)/.exec(ua)?.[1]?.trim();
  let browser = 'غير معروف';
  for (const [re, n] of [[/SamsungBrowser\/(\d+)/, 'Samsung Browser'], [/Edg\/(\d+)/, 'Edge'], [/OPR\/(\d+)/, 'Opera'], [/Firefox\/(\d+)/, 'Firefox'], [/(?:Chrome|CriOS)\/(\d+)/, 'Chrome'], [/Version\/(\d+).*Safari/, 'Safari']]) {
    const m = re.exec(ua); if (m) { browser = `${n} ${m[1]}`; break; }
  }
  return { device: `${type} - ${os}${model ? ` (${model})` : ''}`.slice(0, 80), browser };
};
