const crypto = require('crypto'), path = require('path');
let Database; // better-sqlite3 لو متثبتة، وإلا sqlite المدمجة في Node 22+
try { Database = require('better-sqlite3'); } catch { ({ DatabaseSync: Database } = require('node:sqlite')); }
const db = new Database(process.env.DB_PATH || path.join(__dirname, 'samar.db'));

db.exec(`
PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS roles(name TEXT PRIMARY KEY, level INTEGER NOT NULL, label TEXT NOT NULL, perms TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL COLLATE NOCASE,
  pass_hash TEXT NOT NULL, salt TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'member' REFERENCES roles(name),
  name_color TEXT DEFAULT '', style TEXT DEFAULT '{}', status_msg TEXT DEFAULT '', avatar TEXT DEFAULT '',
  points INTEGER DEFAULT 0, likes INTEGER DEFAULT 0, created_at INTEGER NOT NULL, last_login INTEGER,
  muted_until INTEGER DEFAULT 0, banned_until INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS rooms(name TEXT PRIMARY KEY, owner_id INTEGER, permanent INTEGER DEFAULT 0, description TEXT DEFAULT '', created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT, room TEXT NOT NULL, user_id INTEGER, name TEXT NOT NULL, text TEXT NOT NULL, ts INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_msg_room ON messages(room, id);
CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY AUTOINCREMENT, reporter TEXT NOT NULL, target TEXT NOT NULL, ts INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS visits(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, left_ts INTEGER, user_id INTEGER, name TEXT NOT NULL, role TEXT NOT NULL, ip TEXT, country TEXT, device TEXT, browser TEXT, did TEXT);
CREATE INDEX IF NOT EXISTS idx_visits_ts ON visits(ts);
CREATE TABLE IF NOT EXISTS blocks(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, value TEXT NOT NULL, by_name TEXT, ts INTEGER NOT NULL, until INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS likes(from_id INTEGER NOT NULL, to_id INTEGER NOT NULL, PRIMARY KEY(from_id, to_id));
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT NOT NULL, action TEXT NOT NULL, target TEXT, details TEXT, ts INTEGER NOT NULL);
`);

try { db.exec("ALTER TABLE users ADD COLUMN style TEXT DEFAULT '{}'"); } catch {} // لقواعد بيانات قديمة
try { db.exec('ALTER TABLE audit ADD COLUMN details TEXT'); } catch {}
const PERMS = { kick: 'طرد', kickroom: 'طرد من الغرفة', mute: 'اسكات', ban: 'باند', tempban: 'باند مؤقت', setrole: 'تغيير الرتب', moverooms: 'نقل بين الغرف', editlikes: 'تعديل الإيكات', reveal: 'كشف النكات', viewlog: 'السجل', viewcases: 'الحالات', settings: 'إعدادات الموقع', roles: 'إدارة الصلاحيات' };
const addRole = db.prepare('INSERT OR IGNORE INTO roles(name,level,label,perms) VALUES(?,?,?,?)');
addRole.run('owner', 100, 'المالك', JSON.stringify(Object.keys(PERMS)));
addRole.run('admin', 80, 'مدير', JSON.stringify(['kick', 'kickroom', 'mute', 'ban', 'tempban', 'setrole', 'moverooms', 'reveal', 'viewlog', 'viewcases']));
addRole.run('mod', 50, 'مشرف', JSON.stringify(['kick', 'kickroom', 'mute']));
addRole.run('member', 10, 'عضو', '[]');
db.prepare("UPDATE roles SET perms = ? WHERE name = 'owner'").run(JSON.stringify(Object.keys(PERMS)));
const addSet = db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)');
addSet.run('site_name', 'سمر');
addSet.run('welcome', 'أهلاً بكم في سمر، ادخل باسم مستعار وابدأ الكلام.');
addSet.run('rules', 'احترم الجميع. ممنوع السب والإساءة والروابط المشبوهة. تقدر تبلّغ عن أي عضو من قايمة المتواجدين.');
const addRoom = db.prepare('INSERT OR IGNORE INTO rooms(name,permanent,created_at) VALUES(?,1,?)');
['الصالة العامة', 'تعارف', 'ألعاب'].forEach(r => addRoom.run(r, Date.now()));

const roles = new Map(db.prepare('SELECT * FROM roles').all().map(r => [r.name, { level: r.level, label: r.label, perms: JSON.parse(r.perms) }]));
const hash = (p, salt) => crypto.scryptSync(p, salt, 64).toString('hex');
const now = () => Date.now();
const COLS = ['likes', 'style', 'muted_until', 'banned_until', 'role', 'name_color', 'status_msg', 'avatar'];

module.exports = {
  db,
  SETTING_KEYS: ['site_name', 'welcome', 'rules'],
  level: r => roles.get(r)?.level ?? 0,
  label: r => roles.get(r)?.label ?? '',
  perms: r => roles.get(r)?.perms ?? [],
  can: (r, p) => (roles.get(r)?.perms ?? []).includes(p),
  roleExists: r => roles.has(r),
  userExists: n => !!db.prepare('SELECT 1 x FROM users WHERE username = ?').get(n),
  createUser(name, pass) {
    const first = db.prepare('SELECT COUNT(*) c FROM users').get().c === 0;
    const salt = crypto.randomBytes(16).toString('hex');
    const r = db.prepare('INSERT INTO users(username,pass_hash,salt,role,created_at,last_login) VALUES(?,?,?,?,?,?)')
      .run(name, hash(pass, salt), salt, first ? 'owner' : 'member', now(), now());
    return db.prepare('SELECT * FROM users WHERE id = ?').get(Number(r.lastInsertRowid));
  },
  login(name, pass) {
    const row = db.prepare('SELECT * FROM users WHERE username = ?').get(name);
    const h = hash(pass, row ? row.salt : 'x');
    if (!row) return null;
    const a = Buffer.from(h, 'hex'), b = Buffer.from(row.pass_hash, 'hex');
    return a.length === b.length && crypto.timingSafeEqual(a, b) ? row : null;
  },
  visit: (u, i) => Number(db.prepare('INSERT INTO visits(ts,user_id,name,role,ip,country,device,browser,did) VALUES(?,?,?,?,?,?,?,?,?)').run(now(), u.uid, u.name, u.role, i.ip, i.country, i.device, i.browser, i.did).lastInsertRowid),
  leaveVisit: id => id && db.prepare('UPDATE visits SET left_ts = ? WHERE id = ?').run(now(), id),
  visits: () => db.prepare('SELECT ts,left_ts,name,role,ip,country,device,browser FROM visits ORDER BY id DESC LIMIT 100').all(),
  cases: () => db.prepare('SELECT ts,actor,action,target,details FROM audit ORDER BY id DESC LIMIT 100').all(),
  sameDevice: (did, name) => did ? db.prepare('SELECT DISTINCT name FROM visits WHERE did = ? AND name != ? LIMIT 8').all(did, name).map(r => r.name) : [],
  addBlock: (kind, value, by, until) => value && db.prepare('INSERT INTO blocks(kind,value,by_name,ts,until) VALUES(?,?,?,?,?)').run(kind, value, by, now(), until),
  blockedBy: (ip, did) => db.prepare("SELECT 1 x FROM blocks WHERE until > ? AND ((kind = 'ip' AND value = ?) OR (kind = 'device' AND value = ?)) LIMIT 1").get(now(), ip || '-', did || '-'),
  blocks: () => db.prepare('SELECT id,kind,value,by_name,ts,until FROM blocks WHERE until > ? ORDER BY id DESC LIMIT 100').all(now()),
  delBlock: id => db.prepare('DELETE FROM blocks WHERE id = ?').run(id),
  PERMS,
  rolesList: () => [...roles].map(([name, v]) => ({ name, ...v })),
  setPerms(r, list) {
    const ok = [...new Set(list)].filter(k => PERMS[k] && (r === 'owner' || k !== 'roles'));
    db.prepare('UPDATE roles SET perms = ? WHERE name = ?').run(JSON.stringify(ok), r);
    roles.get(r).perms = ok;
  },
  userByName: n => db.prepare('SELECT username,role,points,likes,status_msg,style FROM users WHERE username = ?').get(n),
  stats: uid => db.prepare('SELECT points, likes FROM users WHERE id = ?').get(uid) ?? { points: 0, likes: 0 },
  like(from, to) {
    const had = db.prepare('SELECT 1 x FROM likes WHERE from_id = ? AND to_id = ?').get(from, to);
    if (had) { db.prepare('DELETE FROM likes WHERE from_id = ? AND to_id = ?').run(from, to); db.prepare('UPDATE users SET likes = MAX(likes - 1, 0) WHERE id = ?').run(to); }
    else { db.prepare('INSERT INTO likes(from_id,to_id) VALUES(?,?)').run(from, to); db.prepare('UPDATE users SET likes = likes + 1 WHERE id = ?').run(to); }
  },
  setPass(uid, pass) {
    const salt = crypto.randomBytes(16).toString('hex');
    db.prepare('UPDATE users SET pass_hash = ?, salt = ? WHERE id = ?').run(hash(pass, salt), salt, uid);
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(uid);
  },
  newSession(uid) {
    const t = crypto.randomBytes(24).toString('hex');
    db.prepare('INSERT INTO sessions(token,user_id,created_at) VALUES(?,?,?)').run(t, uid, now());
    return t;
  },
  sessionUser: t => db.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ?').get(t),
  touch: uid => db.prepare('UPDATE users SET last_login = ? WHERE id = ?').run(now(), uid),
  setCol(uid, col, val) { if (!COLS.includes(col)) throw new Error('bad column'); db.prepare(`UPDATE users SET ${col} = ? WHERE id = ?`).run(val, uid); },
  addPoint: uid => db.prepare('UPDATE users SET points = points + 1 WHERE id = ?').run(uid),
  setting: k => db.prepare('SELECT value FROM settings WHERE key = ?').get(k)?.value ?? '',
  setSetting: (k, v) => db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(k, v),
  addRoom: (n, uid) => db.prepare('INSERT INTO rooms(name,owner_id,permanent,created_at) VALUES(?,?,0,?)').run(n, uid, now()),
  delRoom: n => db.prepare('DELETE FROM rooms WHERE name = ?').run(n),
  logMsg: (room, uid, name, text) => db.prepare('INSERT INTO messages(room,user_id,name,text,ts) VALUES(?,?,?,?,?)').run(room, uid, name, text, now()),
  history: room => db.prepare('SELECT name, text FROM messages WHERE room = ? ORDER BY id DESC LIMIT 50').all(room).reverse(),
  report: (a, b) => db.prepare('INSERT INTO reports(reporter,target,ts) VALUES(?,?,?)').run(a, b, now()),
  audit: (actor, action, target, details) => db.prepare('INSERT INTO audit(actor,action,target,details,ts) VALUES(?,?,?,?,?)').run(actor, action, target ?? null, details ?? null, now()),
  prune() {
    db.prepare('DELETE FROM messages WHERE ts < ?').run(now() - 7 * 864e5);
    db.prepare('DELETE FROM sessions WHERE created_at < ?').run(now() - 30 * 864e5);
    db.prepare('DELETE FROM visits WHERE ts < ?').run(now() - 90 * 864e5);
    db.prepare('DELETE FROM audit WHERE ts < ?').run(now() - 180 * 864e5);
    db.prepare('DELETE FROM blocks WHERE until < ?').run(now());
  },
};
