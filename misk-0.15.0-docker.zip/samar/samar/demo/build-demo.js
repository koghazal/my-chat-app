// يبني demo/preview.html من public/index.html + demo/mock.js (نسخة تجريبية بدون سيرفر)
// التشغيل: node demo/build-demo.js
const fs = require('fs'), path = require('path');
const page = fs.readFileSync(path.join(__dirname, '..', 'public', 'index.html'), 'utf8');
const rb = "window.__rb = 'data:image/gif;base64," + fs.readFileSync(path.join(__dirname, 'rbanner.gif')).toString('base64') + "';\n";
const mock = rb + fs.readFileSync(path.join(__dirname, '..', 'bot-core.js'), 'utf8') + '\n' + fs.readFileSync(path.join(__dirname, 'mock.js'), 'utf8');
const mark = '<script>\nconst $ = s => document.querySelector(s);';
if (!page.includes(mark)) throw new Error('مش لاقي بداية سكريبت الصفحة');
const flags = 'data:image/png;base64,' + fs.readFileSync(path.join(__dirname, '..', 'public', 'flags.png')).toString('base64');
const out = page.replace('url(/flags.png)', () => 'url(' + flags + ')').replace(mark, () => '<script>\n' + mock + '\n</script>\n' + mark).replace('<title>مسك</title>', () => '<title>مسك - نسخة تجريبية</title>');
fs.writeFileSync(path.join(__dirname, 'preview.html'), out);
console.log('تم: demo/preview.html (' + Math.round(out.length / 1024) + ' ك.ب)');
