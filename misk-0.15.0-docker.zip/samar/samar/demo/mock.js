/* سيرفر وهمي للمعاينة فقط: كل حاجة بتتحاكى جوه الصفحة، مفيش اتصال حقيقي ولا حفظ بعد التحديث.
   بيتحقن تلقائيًا في preview.html بواسطة demo/build-demo.js */
(() => {
  const nd = x => String(x).replace(/[\u0660-\u0669]/g, c => c.charCodeAt(0) - 1632).replace(/[\u06f0-\u06f9]/g, c => c.charCodeAt(0) - 1776);
  const ALL = { kick: 'طرد', kickroom: 'طرد من الغرفة', mute: 'اسكات', ban: 'باند', tempban: 'باند مؤقت', setrole: 'تغيير الرتب', moverooms: 'نقل بين الغرف', editlikes: 'تعديل الإيكات', reveal: 'كشف النكات', viewlog: 'السجل', viewcases: 'الحالات', settings: 'إعدادات الموقع', roles: 'إدارة الصلاحيات', stats: 'الإحصائيات', filter: 'فلتر الكلمات', shortcuts: 'الاختصارات', welcome: 'رسائل الترحيب', assets: 'رفع البنرات والإيموجي', wallmod: 'إدارة الحائط', roomadmin: 'إدارة الغرف', reports: 'البلاغات', delmsg: 'حذف الرسائل', members: 'العضويات' };
  const rid = () => Array.from({ length: 24 }, () => '0123456789abcdef'[Math.random() * 16 | 0]).join('');
  const now = () => Date.now();
  // الديمو مفيهوش سيرفر فمقدرش أعرف الايبي؛ بقرّب الدولة من منطقة وقت جهازك. على الموقع الحقيقي بتتحدد من الايبي فعلًا.
  const MYCC = (() => { try { const z = Intl.DateTimeFormat().resolvedOptions().timeZone || '', Z = { 'Asia/Riyadh': 'SA', 'Africa/Cairo': 'EG', 'Asia/Dubai': 'AE', 'Asia/Kuwait': 'KW', 'Asia/Qatar': 'QA', 'Asia/Bahrain': 'BH', 'Asia/Muscat': 'OM', 'Asia/Baghdad': 'IQ', 'Asia/Amman': 'JO', 'Asia/Beirut': 'LB', 'Asia/Damascus': 'SY', 'Africa/Tripoli': 'LY', 'Africa/Tunis': 'TN', 'Africa/Algiers': 'DZ', 'Africa/Casablanca': 'MA', 'Africa/Khartoum': 'SD', 'Asia/Aden': 'YE', 'Asia/Gaza': 'PS', 'Asia/Hebron': 'PS', 'Asia/Jerusalem': 'PS', 'Europe/Istanbul': 'TR', 'Europe/London': 'GB', 'America/New_York': 'US', 'America/Chicago': 'US', 'America/Los_Angeles': 'US', 'Europe/Paris': 'FR', 'Europe/Berlin': 'DE' }; if (Z[z]) return Z[z]; const m = /-([A-Z]{2})$/.exec(navigator.language || ''); return m ? m[1] : ''; } catch { return ''; } })();
  const S = {
    site: { t: 'site', name: 'مسك', welcome: 'نسخة تجريبية: كل حاجة هنا محاكاة، جرّب براحتك. ادخل بـ «دخول الأعضاء» (أي اسم وأي كلمة مرور) عشان تدخل كمالك وتشوف كل الميزات.', rules: 'احترم الجميع. ممنوع السب والإساءة والروابط المشبوهة. تقدر تبلّغ عن أي عضو من قايمة المتواجدين.', regOpen: true, guestOpen: true, accent: '', banner: '', emojis: [] },
    rooms: ['الصالة العامة', 'تعارف', 'ألعاب'], welcomes: { 'تعارف': 'اتعرف على الناس هنا، قول اسمك وبلدك.' },
    roles: [{ name: 'admin', label: 'مدير', level: 80, color: '#ff8a8a', perms: ['kick', 'kickroom', 'mute', 'ban', 'tempban', 'setrole', 'moverooms', 'reveal', 'viewlog', 'viewcases', 'stats', 'wallmod'] }, { name: 'mod', label: 'مشرف', level: 50, color: '#7fd1ff', perms: ['kick', 'kickroom', 'mute'] }, { name: 'member', label: 'عضو', level: 10, color: '', perms: [] }],
    filter: '', shortcuts: { 'س1': 'السلام عليكم ورحمة الله وبركاته', 'س2': 'وعليكم السلام ورحمة الله وبركاته', 'س3': 'أهلاً وسهلاً بيك' },
    bots: [{ id: 101, name: 'مسك بوت', status: 'مساعد الشات 🤖', style: { n: '#7be0c3' }, role: 'bot', label: 'بوت', color: '#7be0c3', likes: 0, points: 0, room: 'الصالة العامة', cc: '', present: true, muted: false, isBot: true }],
    bot: { enabled: true, mod: true, rules: '', bad: '' },
    cases: [{ ts: now() - 3600e3, actor: 'سامي', action: 'ban', target: 'مزعج', details: 'دائم' }],
    blocks: [{ id: 1, kind: 'ip', value: '203.0.113.9', by_name: 'سامي', ts: now() - 7200e3, until: now() + 864e5 }],
    posts: [],
    comments: {}, nextPost: 1, nextCm: 1, msgCount: 482,
  };

  // إطارات وخلفيات جاهزة للتجربة (رسومات SVG بسيطة متولدة هنا)
  const svg = x => 'data:image/svg+xml;utf8,' + encodeURIComponent(x);
  const ring = (a, b) => svg(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs><circle cx="100" cy="100" r="90" fill="none" stroke="url(#g)" stroke-width="14"/><circle cx="100" cy="100" r="76" fill="none" stroke="#fff8" stroke-width="3" stroke-dasharray="6 8"/></svg>`);
  const wave = (a, b, c) => svg(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 650 186" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs><rect width="650" height="186" fill="url(#g)"/><path d="M0 130 Q160 70 325 120 T650 100 V186 H0Z" fill="${c}" opacity=".35"/><circle cx="540" cy="50" r="34" fill="#fff" opacity=".18"/></svg>`);
  window.__files = window.__files || {};
  const RB = '/u/' + 'a1b2c3d4e5f60718293a4b5c' + '.gif'; window.__files[RB] = window.__rb; S.site.rbanners = [RB];
  const gal = (kind, art) => art.map((u, i) => { const url = '/u/' + rid() + '.png'; window.__files[url] = u; return { id: (kind === 'frame' ? 100 : 200) + i, url }; });
  S.frames = gal('frame', [ring('#f2c46b', '#b7852b'), ring('#a65be8', '#6a5ae0'), ring('#26c6a5', '#2a7f9c'), ring('#ff5f9e', '#e0407f'), ring('#e8f1ef', '#8aa3a0')]);
  S.bgs = gal('bg', [wave('#1d4543', '#5b4b8c', '#f2a93b'), wave('#2a3f55', '#4a8a85', '#e8f1ef'), wave('#5b2a4e', '#e0407f', '#f2c46b'), wave('#14302f', '#2e6b32', '#7be07b')]);
  S.notifs = [];
  S.nid = 1; S.visitors = [];
  S.act = { msgs: {}, posts: {}, comments: {}, likes: {}, visits: {} };
  const BC = window.MiskBot, BOT = new BC.Bot(); window.__bot = BOT;
  const RANKSET = { day: 1, week: 4, month: 11 };
  class Sock {
    constructor() { this.mid = 1000;
      this.readyState = 0; this.room = ''; this.me = null; this.said = 0; this.sty = {}; this.status = ''; this.av = ''; this.likes = 0; this.look = { frame: '', bg: '' }; this.mine = { msgs: 0, posts: 0, comments: 0, likes: 0 }; window.__sock = this;
      setTimeout(() => { this.readyState = 1; this.onopen && this.onopen(); this.r(S.site, 10); this.online(); }, 300);
    }
    r(o, d = 40) { setTimeout(() => this.onmessage && this.onmessage({ data: JSON.stringify(o) }), d); }
    owner() { return this.me && this.me.role === 'owner'; }
    perms() { return this.owner() ? Object.keys(ALL) : []; }
    can(p) { return this.perms().includes(p); }
    users() { return this.me ? [{ id: 1, name: this.me.name, dn: this.deco || '', role: this.me.role, label: this.owner() ? 'المالك' : '', color: this.owner() ? '#f2c46b' : '', status: this.status, style: this.sty, av: this.av, fr: this.look.frame, bgi: this.look.bg, cc: MYCC, member: this.me.role !== 'guest', ri: this.owner() ? this.ric('owner') : this.ric(this.me.role), ...this.rs(this.owner() ? 'owner' : this.me.role) }, ...(this.room ? this.here() : S.bots.filter(b => b.present)).map(b => ({ ...b, status: b.muted ? '\u{1F507} مكتوم' : b.status, av: '', member: true, ri: this.ric(b.role), ...this.rs(b.role) }))] : []; }
    here() { return S.bots.filter(b => b.present && b.room === this.room); }
    online() { const P = S.bots.filter(b => b.present); this.r({ t: 'online', count: P.length + (this.me ? 1 : 0), ids: [...P.map(b => b.id), ...(this.me ? [1] : [])], list: [...P.map(b => ({ id: b.id, name: b.name, room: b.room, cc: b.cc })), ...(this.me ? [{ id: 1, name: this.me.name, room: this.room, cc: MYCC }] : [])] }); }
    roomsList() { this.r({ t: 'rooms', list: S.rooms.map(n => ({ name: n, count: S.bots.filter(b => b.present && b.room === n).length + (n === this.room ? 1 : 0), locked: !!(S.locked && S.locked.has(n)), perm: ['الصالة العامة', 'تعارف', 'ألعاب'].includes(n) })) }); }
    refresh() { this.r({ t: 'users', list: this.users() }); this.roomsList(); this.online(); }
    notice(title, text) { this.r({ t: 'notice', title, text }); }
    err(text) { this.r({ t: 'err', text }); }
    audit(action, target, details) { S.cases.unshift({ ts: now(), actor: this.me.name, action, target, details }); }
    evSys(ev, text, room) { this.r({ t: 'sys', ev, text, id: 1, name: this.me.name, dn: this.deco || '', av: this.av, fr: this.look.frame, room }); }
    join(room) {
      if (this.room) this.evSys('leave', 'غادر الغرفة', this.room);
      this.room = room;
      this.r({ t: 'joined', room, rw: S.welcomes[room] || '' });
      this.r({ t: 'history', list: [] });
      this.r({ t: 'users', list: this.users() });
      this.evSys('enter', 'دخل الغرفة', room);
      this.roomsList(); this.online();
      if (room === 'الصالة العامة' && !this.welcomed) { this.welcomed = true; setTimeout(() => this.botMsg(BOT.welcome(this.me.name)), 900); }
    }
    botMsg(text) { const b = S.bots[0]; if (b.present && b.room === this.room) this.r({ t: 'msg', mid: ++this.mid, id: b.id, name: b.name, dn: '', text, style: b.style, av: '', fr: '', bgi: '', file: null }, 0); }
    filtered(t) { S.filter.split(/[\n,،]+/).map(x => x.trim()).filter(Boolean).forEach(w => { t = t.split(w).join('***'); }); return t; }
    who(id) {
      const me = id === 1, b = me ? null : S.bots.find(x => x.id === id); if (!me && !b) return;
      if (b && !b.present) return this.r({ t: 'whois', id: null, name: b.name, role: b.role, label: b.label, color: b.color, av: '', room: null, status: b.status, style: b.style, points: b.points, likes: b.likes, member: true, offline: true });
      this.r({ t: 'whois', id, name: me ? this.me.name : b.name, role: me ? this.me.role : b.role, label: me ? (this.owner() ? 'المالك' : '') : b.label, color: me ? (this.owner() ? '#f2c46b' : '') : b.color, av: me ? this.av : '', fr: me ? this.look.frame : '', bgi: me ? this.look.bg : '', cc: me ? MYCC : b.cc, online: true, room: me ? this.room : b.room, status: me ? this.status : (b.muted ? '\u{1F507} مكتوم' : b.status), style: me ? this.sty : b.style, points: me ? 12 : b.points, likes: me ? this.likes : b.likes, member: me ? this.me.role !== 'guest' : true, vf: 0, views: me ? 3 : 0, low: !me, same: !me, ...this.rs(me ? (this.owner() ? 'owner' : this.me.role) : b.role), ri: me ? (this.owner() ? this.ric('owner') : this.ric(this.me.role)) : this.ric(b.role) });
    }
    rs(role) { const x = (S.roleStyle || (S.roleStyle = {}))[role] || {}; return { rn: x.n || '', rb: x.b || '' }; }
    ric(role) { return (S.roleIcons || (S.roleIcons = { owner: RB }))[role] || ''; }
    rolesMsg() { return { t: 'roles', catalog: ALL, mine: this.owner() ? 100 : 10, list: [...(this.owner() ? [{ name: 'owner', label: 'المالك', level: 100, color: '#f2c46b', perms: [], icon: this.ric('owner'), ncolor: this.rs('owner').rn, mbg: this.rs('owner').rb }] : []), ...S.roles.map(r => ({ ...r, icon: this.ric(r.name), ncolor: this.rs(r.name).rn, mbg: this.rs(r.name).rb }))] }; }
    wall() {
      this.r({ t: 'wall', canMod: this.can('wallmod'), list: S.posts.slice().sort((a, b) => b.id - a.id).map(p => ({ id: p.id, uid: p.uid, name: p.name, text: p.text, img: p.img, ts: p.ts, av: p.av, label: p.label, color: p.color, nc: p.nc, likes: p.likes + (p.liked ? 1 : 0), cc: (S.comments[p.id] || []).length, liked: p.liked, mine: p.uid === 1 })) });
    }
    pushN(kind, text, from) { if (!this.me || this.me.role === 'guest') return; const n = { id: S.nid++, kind, text, from_name: from, ts: now(), read: 0 }; S.notifs.unshift(n); this.r({ t: 'notif', n, unread: S.notifs.filter(x => !x.read).length }); }
    rankList(field) {
      const f = { day: .35, week: 1, month: 3.2 }[this.period] || 1, nm = {};
      const rows = Object.entries(S.act[field] || {}).map(([id, n]) => ({ uid: +id, name: nm[id], av: '', fr: '', n: Math.round(n * f) }));
      if (this.mine[field] > 0) rows.push({ uid: 1, name: this.me.name, av: this.av, fr: this.look.frame, n: this.mine[field] });
      return rows.filter(x => x.n > 0).sort((a, b) => b.n - a.n).slice(0, 10);
    }
    gallery() { this.r({ t: 'gallery', frames: S.frames, bgs: S.bgs, frame: this.look.frame, bg: this.look.bg, canAdd: this.owner() }); }
    looks() { this.r({ t: 'looks', frame: this.look.frame, bg: this.look.bg }); this.r({ t: 'users', list: this.users() }, 60); }
    expand(t) { return t.split(/(\s+)/).map(p => { const k = nd(p); return p.trim() && Object.hasOwn(S.shortcuts, k) ? S.shortcuts[k] : p; }).join(''); }
    comments(id) { this.r({ t: 'comments', id, canMod: this.can('wallmod'), list: (S.comments[id] || []).map(c => ({ ...c, mine: c.uid === 1 })) }); }
    send(d) {
      const m = JSON.parse(d), M = this.me;
      if (m.t === 'login' || m.t === 'register') {
        const guest = m.t === 'login' && m.pass === undefined;
        if (guest && !S.site.guestOpen) return this.err('دخول الزوار متوقف حاليًا، سجّل دخول كعضو');
        if (m.t === 'register' && !S.site.regOpen) return this.err('التسجيل الجديد متوقف حاليًا');
        const nm = String(m.name || '').replace(/[\p{Cc}\p{Cf}]/gu, '').replace(/\s+/g, ' ').trim();
        if (!new RegExp('^[\\p{L}\\p{N}_ ]{' + (m.t === 'register' ? 3 : 2) + ',20}$', 'u').test(nm)) return this.err('الاسم لازم حروف وأرقام فقط (2-20 حرف)');
        if (m.t === 'register' && String(m.pass || '').length < 8) return this.err('كلمة المرور لازم تكون 8 أحرف على الأقل');
        if (!nm) return;
        this.me = { name: nm, role: guest ? 'guest' : 'owner' };
        this.r({ t: 'welcome', id: 1, name: this.me.name, role: this.me.role, perms: this.perms(), upkey: 'demo', av: '', fr: '', bgi: '', unread: guest ? 0 : S.notifs.filter(n => !n.read).length });
        return this.join('الصالة العامة');
      }
      if (!M) return;
      if (m.t === 'leave') { if (!this.room) return; this.evSys('leave', 'غادر الغرفة', this.room); this.room = ''; this.r({ t: 'left' }); this.r({ t: 'users', list: this.users() }); this.roomsList(); this.online(); return; }
      if (m.t === 'join') { if (S.rooms.includes(m.room) && m.room !== this.room) this.join(m.room); }
      else if (m.t === 'mkroom') { S.rooms.push(m.name); this.join(m.name); }
      else if (m.t === 'msg') {
        const raw = String(m.text || '').trim().slice(0, 300), text = this.filtered(this.expand(raw).slice(0, 600));
        if (!text && !m.file) return; S.msgCount++;
        this.mine.msgs++;
        this.r({ t: 'msg', mid: ++this.mid, id: 1, ri: this.owner() ? this.ric('owner') : this.ric(M.role), ...this.rs(this.owner() ? 'owner' : M.role), name: M.name, dn: this.deco || '', text, style: this.sty, av: this.av, fr: this.look.frame, bgi: this.look.bg, file: m.file || null });
        const rp = BOT.reply(text, M.name, Date.now(), 'u1'); if (rp) setTimeout(() => this.botMsg(rp), 900 + Math.random() * 700);
        S.bots.filter(b => b.fakeId && b.kind === 'bot' && b.present && !b.muted && b.room === this.room).forEach(b => { const r2 = b.core.reply(text, this.me.name, Date.now(), "u1"); if (r2) setTimeout(() => { if (b.present && b.room === this.room) this.r({ t: 'msg', mid: ++this.mid, id: b.id, ri: this.ric(b.role), ...this.rs(b.role), name: b.name, dn: b.dn || '', text: r2, style: b.style, av: '', fr: '', bgi: '', file: null }); }, 900 + Math.random() * 600); });
      } else if (m.t === 'pm') {
        const to = S.bots.find(b => b.id === m.to && b.present); if (!to) return this.err('العضو ده مش متصل دلوقتي'); const text = this.filtered(this.expand(String(m.text || '').trim()));
        this.r({ t: 'pm', from: 1, fromName: M.name, to: to.id, toName: to.name, text, file: m.file || null, fromAv: this.av, toAv: '' });
        if (to.fakeId && to.kind === 'bot' && !to.muted) this.r({ t: 'pm', from: to.id, fromName: to.name, to: 1, toName: M.name, text: to.core.pm(text, M.name), file: null, fromAv: '', toAv: this.av }, 1000);
        if (!to.muted && to.isBot) this.r({ t: 'pm', from: to.id, fromName: to.name, to: 1, toName: M.name, text: BOT.pm(text, M.name), file: null, fromAv: '', toAv: this.av }, 1000);
      } else if (m.t === 'profile' && M.role !== 'guest') {
        if ('deco' in m) { const d = String(m.deco || '').trim().slice(0, 24); if (d && S.bots.some(b => b.name === d)) this.err('الزخرفة دي مستخدمة أو شبه اسم عضو تاني، اختار غيرها'); else this.deco = d; }
        this.status = m.status || ''; this.sty = { n: m.n, t: m.tx, b: m.b, s: m.s }; this.r({ t: 'users', list: this.users() }); }
      else if (m.t === 'avdel') { this.av = ''; this.r({ t: 'avatar', url: '' }); this.r({ t: 'users', list: this.users() }); }
      else if (m.t === 'whois') { const b = m.id != null ? { id: m.id } : (m.name === M.name ? { id: 1 } : S.bots.find(x => x.name === m.name)); b ? this.who(b.id) : this.notice('غير متصل', 'العضو ده خرج من الدردشة.'); }
      else if (m.t === 'like') { const b = S.bots.find(x => x.id === m.id); if (b && M.role !== 'guest') { b.liked = !b.liked; b.likes += b.liked ? 1 : -1; this.who(b.id); } }
      else if (m.t === 'alert') { const t = String(m.text || '').trim().slice(0, 200); if (!t) return; const b = S.bots.find(x => x.id === m.id); this.notice('تم إرسال التنبيه', 'وصلت رسالتك إلى "' + (b ? b.name : 'العضو') + '".'); }
      else if (m.t === 'report') this.notice('تم إرسال البلاغ', 'تم تسجيل بلاغك (تجريبي).');
      else if (m.t === 'passwd') this.notice('تم تغيير كلمة المرور', 'كلمة مرورك اتغيرت (تجريبي).');
      else if (m.t === 'reveal') { if (!this.can('reveal')) return; const t = S.bots.find(b => b.id === m.id); if (t && t.isBot) return this.err('ده مسك بوت، مفيش ليه ايبي أو جهاز'); }
      else if (m.t === 'logs') {
        const n = now();
        this.r({ t: 'logs', kind: m.kind, rows: m.kind === 'cases' ? S.cases : m.kind === 'blocks' ? S.blocks : [{ ts: n - 600e3, left_ts: null, name: M.name, role: M.role, label: this.owner() ? 'المالك' : '', ip: '203.0.113.5', country: MYCC, countryName: MYCC === 'PS' ? 'فلسطين' : MYCC ? (() => { try { return new Intl.DisplayNames(['ar'], { type: 'region' }).of(MYCC); } catch { return MYCC; } })() : '', device: (/Android|iPhone|Mobi/i.test(navigator.userAgent) ? 'موبايل' : 'كمبيوتر'), browser: '' }, { ts: n - 5400e3, left_ts: n - 3600e3, name: 'نور', role: 'member', label: 'عضو', ip: '198.51.100.23', country: 'SA', countryName: 'السعودية', device: 'موبايل - iOS', browser: 'Safari 17' }, { ts: n - 9000e3, left_ts: n - 7000e3, name: 'زائر55', role: 'guest', ip: '192.0.2.77', country: 'AE', countryName: 'الإمارات', device: 'كمبيوتر - Windows', browser: 'Edge 126' }] });
      } else if (m.t === 'unblock') { const bk = S.blocks.find(b => b.id === m.id); S.blocks = S.blocks.filter(b => b.id !== m.id); if (bk && bk.bot) { const b = S.bots.find(x => x.id === bk.bot); if (b) { b.present = true; this.audit('unblock', b.name, String(m.id)); this.refresh(); if (b.room === this.room) this.r({ t: 'sys', text: b.name + ' دخل الغرفة' }); } } this.r({ t: 'logs', kind: 'blocks', rows: S.blocks }); }
      else if (m.t === 'rolesinfo') this.r(this.rolesMsg());
      else if (m.t === 'cfg') this.r({ t: 'cfg', filter: S.filter, shortcuts: S.shortcuts, welcomes: S.welcomes });
      else if (m.t === 'stats') this.r({ t: 'stats', users: 1, members7: 1, messages: S.msgCount, today: 96, rooms: S.rooms.length, posts: S.posts.length, visits: 31, blocks: S.blocks.length, online: S.bots.length + 1, onlineMembers: S.bots.length + (M.role === 'guest' ? 0 : 1), liveRooms: S.rooms.length, up: 93784, bytes: 2.4e6 });
      else if (m.t === 'notifs') { this.r({ t: 'notifs', list: S.notifs.map(n => ({ ...n })) }); setTimeout(() => S.notifs.forEach(n => { n.read = 1; }), 10); }
      else if (m.t === 'notifclear') { S.notifs = []; this.r({ t: 'notifs', list: [] }); }
      else if (m.t === 'gallery') this.gallery();
      else if (m.t === 'setlook') {
        for (const k of ['frame', 'bg']) if (k in m) { const url = String(m[k] || ''); if (!url || (k === 'frame' ? S.frames : S.bgs).some(x => x.url === url) || url === this.look['own' + k]) this.look[k] = url; }
        this.looks();
      }
      else if (m.t === 'galdel') { if (!this.owner()) return; S.frames = S.frames.filter(x => x.id !== m.id); S.bgs = S.bgs.filter(x => x.id !== m.id); for (const k of ['frame', 'bg']) if (!(k === 'frame' ? S.frames : S.bgs).some(x => x.url === this.look[k]) && this.look['own' + k] !== this.look[k]) this.look[k] = ''; this.audit('galdel', null, ''); this.gallery(); this.looks(); }
      else if (m.t === 'rank') {
        this.period = ['day', 'week', 'month'].includes(m.period) ? m.period : 'day'; const o = { t: 'rank', kind: m.kind, period: this.period };
        if (m.kind === 'trend') o.lists = { posts: this.rankList('posts'), comments: this.rankList('comments') };
        else if (m.kind === 'creator') o.lists = { likes: this.rankList('likes') };
        else if (m.kind === 'stars') o.lists = { msgs: this.rankList('msgs') };
        else if (m.kind === 'visits') o.lists = { top: this.rankList('visits'), recent: M.role === 'guest' ? [] : S.visitors };
        else return; this.r(o);
      }
      else if (m.t === 'wall') this.wall();
      else if (m.t === 'post') {
        if (M.role === 'guest') return this.err('النشر للأعضاء المسجلين فقط');
        const text = this.filtered(String(m.text || '').slice(0, 500).trim()); if (!text && !m.img) return;
        S.posts.push({ id: S.nextPost, uid: 1, name: M.name, text, img: m.img || '', ts: now(), nc: this.sty.n || '', label: this.owner() ? 'المالك' : '', color: this.owner() ? '#f2c46b' : '', likes: 0, liked: false, av: this.av }); S.comments[S.nextPost++] = [];
        this.mine.posts++; this.wall();
      } else if (m.t === 'plike') { const p = S.posts.find(x => x.id === m.id); if (p && M.role !== 'guest') { p.liked = !p.liked; } this.wall(); }
      else if (m.t === 'comments') this.comments(m.id);
      else if (m.t === 'comment') { const t = this.filtered(String(m.text || '').slice(0, 200).trim()); if (!t || M.role === 'guest' || !S.comments[m.id]) return; S.comments[m.id].push({ id: S.nextCm++, uid: 1, name: M.name, text: t, ts: now(), av: this.av, fr: this.look.frame }); this.mine.comments++; this.comments(m.id); this.wall(); }
      else if (m.t === 'delpost') { const p = S.posts.find(x => x.id === m.id); if (p && (p.uid === 1 || this.can('wallmod'))) { S.posts = S.posts.filter(x => x !== p); this.wall(); } }
      else if (m.t === 'delcomment') { for (const k in S.comments) { const c = S.comments[k].find(x => x.id === m.id); if (c && (c.uid === 1 || this.can('wallmod'))) { S.comments[k] = S.comments[k].filter(x => x !== c); this.comments(+k); this.wall(); } } }
      else if (m.t === 'delmsg') this.r({ t: 'delmsg', mid: m.mid });
      else if (m.t === 'ignore') this.notice('تجربة', 'التجاهل بيتحفظ في السيرفر للأعضاء، وده بيتجرب على الموقع الحقيقي.');
      else if (m.t === 'pmthread' || m.t === 'unignore') { }
      else if (m.t === 'admin' && (m.op === 'reports' || m.op === 'repact')) this.r({ t: 'reports', status: 'open', off: 0, open: 0, list: [] });
      else if (m.t === 'admin') this.admin(m);
    }
    fakesMsg() { return { t: 'fakes', max: 20, rooms: S.rooms, roles: [{ name: 'owner', label: 'المالك' }, ...S.roles.map(r => ({ name: r.name, label: r.label }))], list: S.bots.filter(b => b.fakeId).map(b => ({ id: b.fakeId, name: b.name, kind: b.kind, role: b.role, room: b.room === 'الصالة العامة' ? '' : b.room, deco: b.dn || '', status: b.status, color: b.style.n || '', av: '', rules: b.rules || '', likes: b.likes, active: b.present ? 1 : 0, online: b.present, curRoom: b.room })) }; }
    fake(op, m) {
      const F = S.bots.filter(b => b.fakeId);
      if (op === 'fakeget') return this.r(this.fakesMsg());
      const nm = String(m.name || '').trim().slice(0, 20);
      if (op === 'fakeadd' || op === 'fakeedit') {
        if (nm.length < 2) return this.err('الاسم قصير');
        if (nm === BC.NAME || nm === this.me.name || S.bots.some(b => b.name === nm && b.fakeId !== Number(m.id))) return this.err('الاسم ده مستخدم أو شبه اسم تاني');
        if (op === 'fakeadd' && F.length >= 20) return this.err('وصلنا للحد الأقصى (20)');
        const rl = [{ name: 'owner', label: 'المالك', color: '#f2c46b' }, ...S.roles].find(r => r.name === m.role) || S.roles.find(r => r.name === 'member') || { name: 'member', label: 'عضو', color: '' };
        let b = op === 'fakeedit' ? F.find(x => x.fakeId === Number(m.id)) : null; if (op === 'fakeedit' && !b) return;
        const room = S.rooms.includes(m.room) ? m.room : 'الصالة العامة';
        if (!b) { b = { id: 200 + (S.nextFake = (S.nextFake || 0) + 1), fakeId: S.nextFake, points: 0, cc: '', present: false, muted: false, isBot: false }; S.bots.push(b); }
        const wasHere = b.present; if (wasHere) { if (b.room === this.room) this.r({ t: 'sys', text: b.name + ' غادر الغرفة' }); }
        Object.assign(b, { name: nm, kind: m.kind === 'bot' ? 'bot' : 'member', role: rl.name, label: rl.label, color: rl.color || '', dn: String(m.deco || '').slice(0, 24), status: String(m.status || '').slice(0, 60), style: m.color ? { n: m.color } : {}, likes: Math.max(0, Math.floor(+m.likes) || 0), room, rules: String(m.rules || '').slice(0, 6000), present: true });
        b.core = b.kind === 'bot' ? new BC.Bot({ name: nm, rules: b.rules.trim() ? b.rules : BC.DEFAULT_RULES, bad: '' }) : null;
        if (b.room === this.room) this.r({ t: 'sys', ev: 'enter', text: 'دخل الغرفة', id: b.id, name: b.name, dn: b.dn, av: '', fr: '', room: b.room });
        this.refresh(); return this.r(this.fakesMsg());
      }
      const b = F.find(x => x.fakeId === Number(m.id)); if (!b) return;
      if (op === 'fakedel') { if (b.present && b.room === this.room) this.r({ t: 'sys', text: b.name + ' غادر الغرفة' }); S.bots = S.bots.filter(x => x !== b); this.refresh(); }
      if (op === 'fakepower') { b.present = !b.present; if (b.room === this.room) this.r(b.present ? { t: 'sys', ev: 'enter', text: 'دخل الغرفة', id: b.id, name: b.name, dn: b.dn, av: '', fr: '', room: b.room } : { t: 'sys', text: b.name + ' غادر الغرفة' }); this.refresh(); }
      if (op === 'fakesay') { const t = String(m.text || '').trim().slice(0, 300); if (b.present && b.room === this.room && t) this.r({ t: 'msg', mid: ++this.mid, id: b.id, ri: this.ric(b.role), ...this.rs(b.role), name: b.name, dn: b.dn || '', text: t, style: b.style, av: '', fr: '', bgi: '', file: null }); else return this.err('العضو الوهمي مش في غرفتك'); }
      this.r(this.fakesMsg());
    }
    admin(m) {
      const op = m.op, O = this.owner(); if (!O) return this.err('مفيش صلاحية');
      const ok = (t, x) => this.notice(t, x);
      if (op === 'setting') {
        const k = String(m.key), v = String(m.value ?? '').slice(0, 500);
        if (k === 'rooms_bar') S.site.roomsBar = v === '1'; else if (k === 'reg_open') S.site.regOpen = v !== '0'; else if (k === 'guest_open') S.site.guestOpen = v !== '0';
        else if (k === 'site_name') { if (v.length < 2) return this.err('اسم الموقع قصير'); S.site.name = v; }
        else if (k === 'accent') { if (v && !/^#[0-9a-f]{6}$/i.test(v)) return this.err('لون غير صالح'); S.site.accent = v; }
        else if (k === 'banner') S.site.banner = v; else if (k === 'welcome') S.site.welcome = v; else if (k === 'rules') S.site.rules = v; else return;
        this.audit('setting', null, k); return this.r(S.site);
      }
      if (op === 'members') {
        if (!this.can('members')) return; const q = String(m.q || '').trim();
        const all = [{ id: 1, name: this.me.name, dn: this.deco || '', role: this.me.role, label: this.owner() ? 'المالك' : 'عضو', color: this.owner() ? '#f2c46b' : '', av: this.av, fr: this.look.frame, last: now(), banned: 0, muted: 0, vf: 0, vip: 0, online: true, low: false }].filter(x => !q || x.name.includes(q));
        return this.r({ t: 'members', q, off: 0, total: all.length, list: all, roles: S.roles.filter(r => r.name !== 'owner' && r.name !== 'bot').map(r => ({ name: r.name, label: r.label })) });
      }
      if (op === 'mem') return this.notice('تجربة', 'مفيش أعضاء تانيين في النسخة التجريبية، الأوامر دي بتتجرب على الموقع الحقيقي.');
      if (op === 'botget' || op === 'botcfg') {
        if (!this.owner()) return;
        if (op === 'botcfg') { Object.assign(S.bot, { enabled: !!m.enabled, mod: !!m.mod, rules: String(m.rules || '').slice(0, 6000), bad: String(m.bad || '').slice(0, 2000) }); if (S.bot.rules.trim() === BC.DEFAULT_RULES.trim()) S.bot.rules = ''; BOT.setRules(S.bot.rules || BC.DEFAULT_RULES); BOT.setBad(S.bot.bad); S.bots[0].present = S.bot.enabled; this.audit('botcfg', null, (S.bot.enabled ? 'يعمل' : 'متوقف') + ' - ' + BOT.rules.length + ' قاعدة'); this.notice('تم حفظ إعدادات البوت', 'القواعد: ' + BOT.rules.length + ' - المراقبة: ' + (S.bot.mod ? 'شغالة' : 'متوقفة')); this.refresh(); }
        return this.r({ t: 'botcfg', enabled: S.bot.enabled, mod: S.bot.mod, rules: S.bot.rules || BC.DEFAULT_RULES, bad: S.bot.bad, name: BC.NAME, defaults: BC.DEFAULT_RULES });
      }
      if (op === 'filter') { S.filter = String(m.value || '').slice(0, 2000); this.audit('filter', null, ''); return ok('تم حفظ الفلتر', 'الكلمات الممنوعة دلوقتي: ' + S.filter.split(/[\n,،]+/).filter(x => x.trim()).length); }
      if (op === 'shortcuts') { const o = {}; (m.list || []).forEach(([a, b]) => { a = nd(String(a)).replace(/\s/g, '').slice(0, 12); b = String(b).slice(0, 300); if (a && b) o[a] = b; }); S.shortcuts = o; this.audit('shortcuts', null, ''); return ok('تم حفظ الاختصارات', 'عدد الاختصارات: ' + Object.keys(o).length); }
      if (op === 'roomclear' || op === 'roomlock' || op === 'roomdel') {
        const r = String(m.room); if (!S.rooms.includes(r)) return;
        S.locked = S.locked || new Set();
        if (op === 'roomclear') { if (r === this.room) { this.r({ t: 'history', list: [], replace: true }); this.r({ t: 'sys', text: this.me.name + ' مسح رسائل الغرفة' }); } this.audit('roomclear', null, r); return ok('تم مسح الرسائل', 'اتمسحت كل رسائل غرفة "' + r + '".'); }
        if (op === 'roomlock') { const l = !S.locked.has(r); l ? S.locked.add(r) : S.locked.delete(r); this.audit('roomlock', null, r); if (r === this.room) this.r({ t: 'sys', text: this.me.name + (l ? ' قفل الغرفة، المشرفين بس اللي يكتبوا' : ' فتح الغرفة للكتابة') }); this.roomsList(); return ok(l ? 'تم قفل الغرفة' : 'تم فتح الغرفة', 'غرفة "' + r + '" ' + (l ? 'بقت للقراءة فقط لغير المشرفين.' : 'اتفتحت للكل.')); }
        if (['الصالة العامة', 'تعارف', 'ألعاب'].includes(r)) return this.err('الغرف الأساسية مينفعش تتحذف');
        S.rooms = S.rooms.filter(x => x !== r); S.locked.delete(r); this.audit('roomdel', null, r); if (this.room === r) this.join('الصالة العامة'); this.roomsList(); return ok('تم حذف الغرفة', 'غرفة "' + r + '" اتحذفت.');
      }
      if (op === 'roomwelcome') { S.welcomes[m.room] = String(m.text || '').slice(0, 300); this.audit('roomwelcome', null, m.room); return ok('تم حفظ الترحيب', 'ترحيب غرفة "' + m.room + '" اتحفظ.'); }
      if (op === 'mkrole') { const label = String(m.label || '').trim().slice(0, 20); if (label.length < 2) return this.err('اسم الرتبة قصير'); const lv = Math.floor(+m.level); if (!(lv >= 1 && lv < 100)) return this.err('مستوى الرتبة لازم يكون أقل من مستواك'); S.roles.push({ name: 'r' + now().toString(36), label, level: lv, color: /^#[0-9a-f]{6}$/i.test(m.color) ? m.color : '', perms: [] }); this.audit('mkrole', null, label); return this.r(this.rolesMsg()); }
      if (op === 'rolestyle') { this.rs(m.role); const h = v => (/^#[0-9a-f]{6}$/i.test(v) ? v : ''); S.roleStyle[m.role] = { n: h(m.n), b: h(m.b) }; this.audit('editrole', m.role, 'ألوان'); this.refresh(); return this.r(this.rolesMsg()); }
      if (op === 'rbadd' || op === 'rbdel') { const L = S.site.rbanners || (S.site.rbanners = [RB]); if (op === 'rbadd' && m.url && !L.includes(m.url)) L.push(m.url); if (op === 'rbdel') { if (Object.values(S.roleIcons || {}).includes(m.url)) return this.err('البنر ده مستخدم في رتبة، شيله منها الأول'); S.site.rbanners = L.filter(x => x !== m.url); } return this.r(S.site); }
      if (op === 'editrole' && m.role === 'owner') { this.ric('owner'); S.roleIcons.owner = m.icon || ''; this.refresh(); return this.r(this.rolesMsg()); }
      if (op === 'editrole') { const r = S.roles.find(x => x.name === m.role); if (!r) return; r.label = String(m.label || r.label).slice(0, 20); r.color = /^#[0-9a-f]{6}$/i.test(m.color) ? m.color : ''; if (m.icon !== undefined) { this.ric(r.name); S.roleIcons[r.name] = m.icon || ''; } this.audit('editrole', r.name, r.label); this.refresh(); return this.r(this.rolesMsg()); }
      if (op === 'delrole') { if (['admin', 'mod', 'member'].includes(m.role)) return this.err('مينفعش تحذف الرتبة دي'); S.roles = S.roles.filter(x => x.name !== m.role); this.audit('delrole', m.role, ''); return this.r(this.rolesMsg()); }
      if (op === 'setperms') { const r = S.roles.find(x => x.name === m.role); if (r) r.perms = (m.perms || []).filter(k => ALL[k] && k !== 'roles'); this.audit('setperms', m.role, r.perms.join('، ')); return this.r(this.rolesMsg()); }
      if (op === 'emoji') { m.name = nd(String(m.name || '').trim()); if (!m.name) { let i = 1; while (S.site.emojis.some(e => e.name === 'ف' + i)) i++; m.name = 'ف' + i; } if (!/^[\p{L}\p{N}_]{1,16}$/u.test(m.name)) return this.err('اختصار الإيموجي حروف وأرقام فقط (حتى 16)'); S.site.emojis = S.site.emojis.filter(e => e.name !== m.name).concat({ name: m.name, url: m.url }); this.audit('emoji', null, m.name); return this.r(S.site); }
      if (op === 'delemoji') { S.site.emojis = S.site.emojis.filter(e => e.name !== m.name); this.audit('delemoji', null, m.name); return this.r(S.site); }
      if (op === 'restart') { this.audit('restart'); this.r({ t: 'restarting' }); return setTimeout(() => this.onclose && this.onclose(), 900); }
      if (op.startsWith('fake')) return this.fake(op, m);
      // أوامر الإدارة على الأعضاء: بتغيّر الحالة فعليًا زي السيرفر الحقيقي
      const PERM = { kick: 'kick', kickroom: 'kickroom', mute: 'mute', ban: 'ban', tempban: 'tempban', setrole: 'setrole', move: 'moverooms', likes: 'editlikes' };
      const b = S.bots.find(x => x.id === m.target); if (!b || !b.present || !PERM[op] || !this.can(PERM[op])) return;
      if (b.isBot) return this.err('ده مسك بوت، تتحكم فيه من لوحة التحكم ← مسك بوت');
      const L = { kick: 'طرد', kickroom: 'طرد من الغرفة', mute: 'اسكات', ban: 'باند', tempban: 'باند مؤقت', setrole: 'تغيير الرتبة', move: 'نقل لغرفة', likes: 'تعديل الإيكات' };
      const mins = Math.min(Math.max(Math.floor(Number(m.mins)) || 0, 0), 525600), who = '"' + b.name + '"', here = b.room === this.room;
      const det = { mute: mins ? mins + 'د' : 'فك', tempban: mins + 'د', ban: 'دائم', move: m.room, likes: String(m.value), setrole: m.role }[op] || '';
      let said = '';
      const leave = txt => { if (here) this.r({ t: 'sys', text: b.name + ' ' + txt }); };
      if (op === 'kick') { b.present = false; leave('غادر الغرفة'); said = 'تم طرد ' + who + ' من الدردشة وفصله عن الموقع.'; }
      if (op === 'kickroom') { if (b.room === 'الصالة العامة') return ok('ملحوظة', who + ' موجود في الصالة العامة أصلًا.'); leave('غادر الغرفة'); b.room = 'الصالة العامة'; said = 'تم طرد ' + who + ' من الغرفة ونقله إلى الصالة العامة.'; }
      if (op === 'mute') { b.muted = mins > 0; said = mins ? 'تم إسكات ' + who + ' لمدة ' + mins + ' دقيقة. مش هيقدر يكتب رسايل خلال المدة دي.' : 'تم فك الإسكات عن ' + who + ' وبقى يقدر يكتب.'; }
      if (op === 'ban' || op === 'tempban') {
        const mm = Math.max(mins, 1), how = op === 'ban' ? 'بشكل دائم' : 'لمدة ' + mm + ' دقيقة';
        S.blocks.unshift({ id: now(), kind: 'device', value: 'demo-device-' + b.id, by_name: this.me.name, ts: now(), until: now() + (op === 'ban' ? 3650 * 864e5 : mm * 60e3), bot: b.id });
        b.present = false; leave('غادر الغرفة'); said = 'تم حظر ' + who + ' ' + how + ' (الحساب والجهاز). تقدر تفك الحظر من لوحة التحكم ← المحظورين.';
      }
      if (op === 'move') { if (!S.rooms.includes(m.room)) return; if (b.room !== m.room) { leave('غادر الغرفة'); b.room = m.room; if (m.room === this.room) this.r({ t: 'sys', text: b.name + ' دخل الغرفة' }); } said = 'تم نقل ' + who + ' إلى غرفة "' + m.room + '".'; }
      if (op === 'likes') { const n = Math.floor(Number(m.value)); if (!(n >= 0 && n <= 1e9)) return this.err('قيمة غير صالحة'); b.likes = n; said = 'تم تعديل إيكات ' + who + ' إلى ' + n + '.'; }
      if (op === 'setrole') { const r = S.roles.find(x => x.name === m.role); if (!r) return this.err('رتبة غير صالحة'); b.role = r.name; b.label = r.label; b.color = r.color; said = 'تم تغيير رتبة ' + who + ' إلى ' + r.label + '.'; }
      this.audit(op, b.name, det); this.refresh(); ok('تم تنفيذ: ' + L[op], said + '\nتم تسجيل الإجراء في الحالات.');
    }
    close() {}
  }
  // عارض الصفحات الجاهزة بيمنع confirm/prompt، فبنحاكيهم هنا (للنسخة التجريبية فقط)
  let rn = 0; window.confirm = () => true; window.prompt = (q, d) => d || (/غرفة/.test(q) ? 'غرفة جديدة ' + (++rn) : '123456');
  window.WebSocket = Sock;

  // عارض الصفحات بيمنع التحميل وفتح تبويب جديد، فنعرض المرفقات في نافذة داخل الصفحة (للنسخة التجريبية فقط)
  document.addEventListener('click', e => {
    const a = e.target.closest && e.target.closest('a.fl, img.att'); if (!a) return;
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
    const src = a.tagName === 'IMG' ? a.src : a.href, d = document.createElement('div');
    d.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#000c;display:flex;align-items:center;justify-content:center;padding:16px;direction:rtl';
    const box = document.createElement('div'); box.style.cssText = 'background:#0f2a2c;color:#e8f3f2;border:1px solid #2a5b5e;border-radius:14px;padding:14px;max-width:92vw;max-height:86vh;overflow:auto;text-align:center';
    if (a.tagName === 'IMG') { const i = document.createElement('img'); i.src = src; i.style.cssText = 'max-width:100%;max-height:70vh;border-radius:8px'; box.append(i); }
    else {
      const h = document.createElement('div'); h.textContent = a.textContent.replace('\u{1F4CE}', '').trim(); h.style.cssText = 'font-weight:700;margin-bottom:8px'; box.append(h);
      const pre = document.createElement('pre'); pre.style.cssText = 'white-space:pre-wrap;text-align:right;margin:0'; box.append(pre);
      fetch(src).then(r => r.text()).then(t => { pre.textContent = /^[\x09\x0a\x0d\x20-\x7e؀-ۿ]*$/.test(t.slice(0, 500)) ? t.slice(0, 2000) : 'معاينة الملف مش متاحة في النسخة التجريبية، لكنه بيتحمّل عادي في الموقع الحقيقي.'; }).catch(() => { pre.textContent = 'معاينة الملف مش متاحة في النسخة التجريبية.'; });
    }
    const x = document.createElement('button'); x.textContent = 'إغلاق'; x.style.cssText = 'margin-top:10px;padding:8px 18px;border-radius:10px;border:0;background:#2a3f41;color:#e8f3f2;cursor:pointer'; x.onclick = () => d.remove(); box.append(x);
    d.append(box); d.onclick = ev => ev.target === d && d.remove(); document.body.appendChild(d);
  }, true);

  // نافذة اختيار الملف للنسخة التجريبية: اختيار من الجهاز مباشرة، أو عينات جاهزة لو العارض بيمنع نافذة الملفات
  if (!navigator.webdriver) window.__pickHook = (accept, cb) => {
    const old = document.getElementById('demopick'); if (old) old.remove();
    const d = document.createElement('div'); d.id = 'demopick';
    d.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#000a;display:flex;align-items:center;justify-content:center;padding:16px;font-family:inherit;direction:rtl';
    const box = document.createElement('div');
    box.style.cssText = 'background:#0f2a2c;color:#e8f3f2;border:1px solid #2a5b5e;border-radius:14px;padding:16px;max-width:340px;width:100%;box-shadow:0 10px 40px #000a';
    const t = (x, st) => { const e = document.createElement('div'); e.textContent = x; e.style.cssText = st || ''; return e; };
    box.append(t('اختيار ملف', 'font-weight:700;margin-bottom:10px;font-size:16px'));
    const close = () => d.remove(), give = f => { close(); cb(f); };
    const lab = document.createElement('label'); lab.style.cssText = 'display:block;border:1px dashed #3d8a8e;border-radius:10px;padding:12px;text-align:center;cursor:pointer;margin-bottom:10px';
    lab.textContent = 'اسحب ملف من جهازك وأفلته هنا، أو الصق صورة (Ctrl+V)، أو اضغط للاختيار'; const inp = document.createElement('input'); inp.type = 'file'; inp.accept = accept; inp.style.cssText = 'display:block;margin:8px auto 0;max-width:100%';
    inp.onchange = () => inp.files[0] && give(inp.files[0]); lab.append(inp); box.append(lab);
    box.append(t('أو جرّب بعينة جاهزة (لو المتصفح منع اختيار الملفات):', 'font-size:12px;opacity:.8;margin-bottom:6px'));
    const row = document.createElement('div'); row.style.cssText = 'display:flex;gap:8px;flex-wrap:wrap';
    const mk = (label, fn) => { const b = document.createElement('button'); b.type = 'button'; b.textContent = label; b.style.cssText = 'flex:1;min-width:90px;padding:9px;border-radius:10px;border:1px solid #3d8a8e;background:#173d40;color:#e8f3f2;cursor:pointer'; b.onclick = async () => give(await fn()); row.append(b); };
    const img = (c1, c2, label) => () => new Promise(r => { const c = document.createElement('canvas'); c.width = c.height = 320; const x = c.getContext('2d'), g = x.createLinearGradient(0, 0, 320, 320); g.addColorStop(0, c1); g.addColorStop(1, c2); x.fillStyle = g; x.fillRect(0, 0, 320, 320); x.fillStyle = '#fff'; x.font = 'bold 46px sans-serif'; x.textAlign = 'center'; x.fillText(label, 160, 180); c.toBlob(b => r(new File([b], 'sample-' + label + '.png', { type: 'image/png' })), 'image/png'); });
    const isImg = /image/.test(accept) && !/\*\/\*|,/.test(accept) || accept === 'image/*';
    mk('صورة 1', img('#1fa39a', '#0b4f6c', 'A')); mk('صورة 2', img('#e07a5f', '#3d405b', 'B')); mk('صورة 3', img('#f2cc8f', '#81b29a', 'C'));
    if (!isImg) mk('ملف نصي', async () => new File(['ملف تجريبي من مسك'], 'sample.txt', { type: 'text/plain' }));
    box.append(row);
    const x = document.createElement('button'); x.type = 'button'; x.textContent = 'إلغاء'; x.style.cssText = 'margin-top:12px;width:100%;padding:9px;border-radius:10px;border:0;background:#2a3f41;color:#e8f3f2;cursor:pointer'; x.onclick = close; box.append(x);
    const onPaste = e => { const f = e.clipboardData && e.clipboardData.files && e.clipboardData.files[0]; if (f) { e.preventDefault(); document.removeEventListener('paste', onPaste, true); give(f); } };
    document.addEventListener('paste', onPaste, true);
    const drop = e => { e.preventDefault(); e.stopPropagation(); lab.style.background = ''; const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]; if (f) { document.removeEventListener('paste', onPaste, true); give(f); } };
    d.addEventListener('dragover', e => { e.preventDefault(); e.stopPropagation(); lab.style.background = '#173d40'; }, true);
    d.addEventListener('drop', drop, true);
    d.append(box); d.onclick = e => { if (e.target === d) { document.removeEventListener('paste', onPaste, true); close(); } }; document.body.appendChild(d);
  };
  window.__files = window.__files || {};
  const realFetch = window.fetch.bind(window);
  window.fetch = (url, opts = {}) => {
    if (!String(url).startsWith('/upload')) return realFetch(url, opts);
    const f = opts.body, k = new URL(url, 'http://x').searchParams.get('k') || 'msg', name = decodeURIComponent((opts.headers || {})['x-name'] || 'file');
    const ext = ((/\.([a-z0-9]{2,4})$/i.exec(name) || [])[1] || (f.type.split('/')[1] || 'bin').replace('jpeg', 'jpg').replace('plain', 'txt').slice(0, 4)).toLowerCase();
    const kind = /^image\//.test(f.type) ? 'image' : /^audio\//.test(f.type) ? 'audio' : /^video\//.test(f.type) ? 'video' : 'file';
    if (/frame$/.test(k) && !/^image\/(png|webp)$/.test(f.type)) return Promise.resolve(new Response(JSON.stringify({ err: 'الإطار لازم يكون png أو webp بخلفية شفافة' }), { status: 415 }));
    if (k !== 'msg' && kind !== 'image') return Promise.resolve(new Response(JSON.stringify({ err: 'الملف مش صورة صالحة (png, jpg, gif, webp)' }), { status: 415 }));
    const u = '/u/' + rid() + '.' + ext;
    return new Promise(done => {
      const fr = new FileReader();
      const fin = src => {
        window.__files[u] = src;
      if (k === 'avatar' && window.__sock) { const s = window.__sock; s.av = u; s.r({ t: 'avatar', url: u }); s.r({ t: 'users', list: s.users() }, 80); }
      if ((k === 'frame' || k === 'bg') && window.__sock) { const s = window.__sock; s.look[k] = u; s.look['own' + k] = u; s.looks(); }
      if ((k === 'galframe' || k === 'galbg') && window.__sock) { const s = window.__sock; (k === 'galframe' ? S.frames : S.bgs).unshift({ id: now() % 1e6, url: u }); }
        done(new Response(JSON.stringify({ url: u, name, size: f.size, kind }), { status: 200, headers: { 'Content-Type': 'application/json' } }));
      };
      fr.onload = () => fin(String(fr.result)); fr.onerror = () => fin(URL.createObjectURL(f)); fr.readAsDataURL(f);
    });
  };
})();
